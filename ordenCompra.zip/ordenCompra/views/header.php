<header class="header">
    <div class="container logo-nav-container">
        <a href="#" class="logo">LOGO</a>
        <span class="menu-icon">Ver menú</span>
        <nav class="navigation">
            <ul>
                <li><a href="#">Inicio</a></li>
                <li><a href="#">Acerca</a></li>
                <li><a href="#">Servicios</a></li>
                <li><a href="#">Contacto</a></li>
            </ul>
        </nav>
    </div>
</header>

