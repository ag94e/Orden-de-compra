<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/general.css">
    <link rel="stylesheet" href="../styles/header.css">
    <title>Home Captura</title>
</head>
<body>
<?php require_once 'header.php'; ?>
    <a href="captura.php"><button>Capturar proveedor</button></a>
    <a href="captura2.php"><button>Capturar artículo</button></a>
</body>
</html>